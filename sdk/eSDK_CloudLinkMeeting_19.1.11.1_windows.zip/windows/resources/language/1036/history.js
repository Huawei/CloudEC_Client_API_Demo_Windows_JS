module.exports = {
    "HISTORY": "Historique"
}