module.exports={
    "TARGET_TO_CONTEXT":"Посмотреть контекст",
    "HISTORY":"История"
}