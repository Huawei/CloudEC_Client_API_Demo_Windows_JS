


#ifndef __TSDK_WS_DAEMON_INTERFACE_H__
#define __TSDK_WS_DAEMON_INTERFACE_H__

#include "tsdk_ws_daemon_def.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */


TSDK_API TSDK_RESULT tsdk_startup_ws_service_daemon(TSDK_S_WEB_SOCKET_SERVICE_DAEMON_PARAM *service_daemon_param);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif /* __TSDK_WS_DAEMON_INTERFACE_H__ */

